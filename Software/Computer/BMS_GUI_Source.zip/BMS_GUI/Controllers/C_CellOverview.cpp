#include "C_CellOverview.h"

C_CellOverview::C_CellOverview(QObject *parent)
    : QObject{parent}
{

}

int C_CellOverview::i_CellBalancingMask() const
{
    return m_i_CellBalancingMask;
}

void C_CellOverview::seti_CellBalancingMask(int newi_CellBalancingMask)
{
    if (m_i_CellBalancingMask == newi_CellBalancingMask)
        return;
    m_i_CellBalancingMask = newi_CellBalancingMask;
    emit i_CellBalancingMaskChanged();
}

int C_CellOverview::i_CellDeltaU() const
{
    return m_i_CellDeltaU;
}

void C_CellOverview::seti_CellDeltaU(int newi_CellDeltaU)
{
    if (m_i_CellDeltaU == newi_CellDeltaU)
        return;
    m_i_CellDeltaU = newi_CellDeltaU;
    emit i_CellDeltaUChanged();
}
