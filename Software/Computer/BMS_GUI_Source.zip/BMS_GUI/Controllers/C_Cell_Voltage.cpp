#include "C_Cell_Voltage.h"

C_Cell_Voltage::C_Cell_Voltage(QObject *parent)
    : QObject{parent}
    , m_f_Cell_1_Voltage{DEFAULT_VOLTAGE}
    , m_f_Cell_2_Voltage{DEFAULT_VOLTAGE}
    , m_f_Cell_3_Voltage{DEFAULT_VOLTAGE}
    , m_f_Cell_4_Voltage{DEFAULT_VOLTAGE}
    , m_i_Cell_Min_Voltage{DEFAULT_MIN_MAX}
    , m_i_Cell_Max_Voltage{DEFAULT_MIN_MAX}
{

}

float C_Cell_Voltage::f_Cell_1_Voltage() const
{
    return m_f_Cell_1_Voltage;
}

void C_Cell_Voltage::setf_Cell_1_Voltage(float newf_Cell_1_Voltage)
{
    if (qFuzzyCompare(m_f_Cell_1_Voltage, newf_Cell_1_Voltage))
        return;
    m_f_Cell_1_Voltage = newf_Cell_1_Voltage;
    emit f_Cell_1_VoltageChanged();
}

float C_Cell_Voltage::f_Cell_2_Voltage() const
{
    return m_f_Cell_2_Voltage;
}

void C_Cell_Voltage::setf_Cell_2_Voltage(float newf_Cell_2_Voltage)
{
    if (qFuzzyCompare(m_f_Cell_2_Voltage, newf_Cell_2_Voltage))
        return;
    m_f_Cell_2_Voltage = newf_Cell_2_Voltage;
    emit f_Cell_2_VoltageChanged();
}

float C_Cell_Voltage::f_Cell_3_Voltage() const
{
    return m_f_Cell_3_Voltage;
}

void C_Cell_Voltage::setf_Cell_3_Voltage(float newf_Cell_3_Voltage)
{
    if (qFuzzyCompare(m_f_Cell_3_Voltage, newf_Cell_3_Voltage))
        return;
    m_f_Cell_3_Voltage = newf_Cell_3_Voltage;
    emit f_Cell_3_VoltageChanged();
}

float C_Cell_Voltage::f_Cell_4_Voltage() const
{
    return m_f_Cell_4_Voltage;
}

void C_Cell_Voltage::setf_Cell_4_Voltage(float newf_Cell_4_Voltage)
{
    if (qFuzzyCompare(m_f_Cell_4_Voltage, newf_Cell_4_Voltage))
        return;
    m_f_Cell_4_Voltage = newf_Cell_4_Voltage;
    emit f_Cell_4_VoltageChanged();
}

int C_Cell_Voltage::i_Cell_Max_Voltage() const
{
    return m_i_Cell_Max_Voltage;
}

void C_Cell_Voltage::seti_Cell_Max_Voltage(int newi_Cell_Max_Voltage)
{
    if (m_i_Cell_Max_Voltage == newi_Cell_Max_Voltage)
        return;
    m_i_Cell_Max_Voltage = newi_Cell_Max_Voltage;
    emit i_Cell_Max_VoltageChanged();
}

int C_Cell_Voltage::i_Cell_Min_Voltage() const
{
    return m_i_Cell_Min_Voltage;
}

void C_Cell_Voltage::seti_Cell_Min_Voltage(int newi_Cell_Min_Voltage)
{
    if (m_i_Cell_Min_Voltage == newi_Cell_Min_Voltage)
        return;
    m_i_Cell_Min_Voltage = newi_Cell_Min_Voltage;
    emit i_Cell_Min_VoltageChanged();
}
