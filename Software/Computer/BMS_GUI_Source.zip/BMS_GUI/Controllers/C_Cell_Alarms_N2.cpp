#include "C_Cell_Alarms_N2.h"

C_Cell_Alarms_N2::C_Cell_Alarms_N2(QObject *parent)
    : QObject{parent}
    , m_b_Alarm_0{false}
    , m_b_Alarm_1{false}
    , m_b_Alarm_2{false}
    , m_b_Alarm_3{false}
    , m_b_Alarm_4{false}
{

}

bool C_Cell_Alarms_N2::b_Alarm_0() const
{
    return m_b_Alarm_0;
}

void C_Cell_Alarms_N2::setb_Alarm_0(bool newb_Alarm_0)
{
    if (m_b_Alarm_0 == newb_Alarm_0)
        return;
    m_b_Alarm_0 = newb_Alarm_0;
    emit b_Alarm_0Changed();
}

bool C_Cell_Alarms_N2::b_Alarm_1() const
{
    return m_b_Alarm_1;
}

void C_Cell_Alarms_N2::setb_Alarm_1(bool newb_Alarm_1)
{
    if (m_b_Alarm_1 == newb_Alarm_1)
        return;
    m_b_Alarm_1 = newb_Alarm_1;
    emit b_Alarm_1Changed();
}

bool C_Cell_Alarms_N2::b_Alarm_2() const
{
    return m_b_Alarm_2;
}

void C_Cell_Alarms_N2::setb_Alarm_2(bool newb_Alarm_2)
{
    if (m_b_Alarm_2 == newb_Alarm_2)
        return;
    m_b_Alarm_2 = newb_Alarm_2;
    emit b_Alarm_2Changed();
}

bool C_Cell_Alarms_N2::b_Alarm_3() const
{
    return m_b_Alarm_3;
}

void C_Cell_Alarms_N2::setb_Alarm_3(bool newb_Alarm_3)
{
    if (m_b_Alarm_3 == newb_Alarm_3)
        return;
    m_b_Alarm_3 = newb_Alarm_3;
    emit b_Alarm_3Changed();
}

bool C_Cell_Alarms_N2::b_Alarm_4() const
{
    return m_b_Alarm_4;
}

void C_Cell_Alarms_N2::setb_Alarm_4(bool newb_Alarm_4)
{
    if (m_b_Alarm_4 == newb_Alarm_4)
        return;
    m_b_Alarm_4 = newb_Alarm_4;
    emit b_Alarm_4Changed();
}
