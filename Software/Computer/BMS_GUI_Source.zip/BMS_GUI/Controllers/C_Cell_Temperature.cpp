#include "C_Cell_Temperature.h"

C_Cell_Temperature::C_Cell_Temperature(QObject *parent)
    : QObject{parent}
    , m_f_Cell_1_Temperature{DEFAULT_TEMP}
    , m_f_Cell_2_Temperature{DEFAULT_TEMP}
    , m_f_Cell_3_Temperature{DEFAULT_TEMP}
    , m_f_Cell_4_Temperature{DEFAULT_TEMP}
    , m_i_Cell_Min_Temperature{DEFAULT_MIN_MAX}
    , m_i_Cell_Max_Temperature{DEFAULT_MIN_MAX}
{

}

float C_Cell_Temperature::f_Cell_1_Temperature() const
{
    return m_f_Cell_1_Temperature;
}

void C_Cell_Temperature::setf_Cell_1_Temperature(float newf_Cell_1_Temperature)
{
    if (qFuzzyCompare(m_f_Cell_1_Temperature, newf_Cell_1_Temperature))
        return;
    m_f_Cell_1_Temperature = newf_Cell_1_Temperature;
    emit f_Cell_1_TemperatureChanged();
}

float C_Cell_Temperature::f_Cell_2_Temperature() const
{
    return m_f_Cell_2_Temperature;
}

void C_Cell_Temperature::setf_Cell_2_Temperature(float newf_Cell_2_Temperature)
{
    if (qFuzzyCompare(m_f_Cell_2_Temperature, newf_Cell_2_Temperature))
        return;
    m_f_Cell_2_Temperature = newf_Cell_2_Temperature;
    emit f_Cell_2_TemperatureChanged();
}

float C_Cell_Temperature::f_Cell_3_Temperature() const
{
    return m_f_Cell_3_Temperature;
}

void C_Cell_Temperature::setf_Cell_3_Temperature(float newf_Cell_3_Temperature)
{
    if (qFuzzyCompare(m_f_Cell_3_Temperature, newf_Cell_3_Temperature))
        return;
    m_f_Cell_3_Temperature = newf_Cell_3_Temperature;
    emit f_Cell_3_TemperatureChanged();
}

float C_Cell_Temperature::f_Cell_4_Temperature() const
{
    return m_f_Cell_4_Temperature;
}

void C_Cell_Temperature::setf_Cell_4_Temperature(float newf_Cell_4_Temperature)
{
    if (qFuzzyCompare(m_f_Cell_4_Temperature, newf_Cell_4_Temperature))
        return;
    m_f_Cell_4_Temperature = newf_Cell_4_Temperature;
    emit f_Cell_4_TemperatureChanged();
}

int C_Cell_Temperature::i_Cell_Max_Temperature() const
{
    return m_i_Cell_Max_Temperature;
}

void C_Cell_Temperature::seti_Cell_Max_Temperature(int newi_Cell_Max_Temperature)
{
    if (m_i_Cell_Max_Temperature == newi_Cell_Max_Temperature)
        return;
    m_i_Cell_Max_Temperature = newi_Cell_Max_Temperature;
    emit i_Cell_Max_TemperatureChanged();
}

int C_Cell_Temperature::i_Cell_Min_Temperature() const
{
    return m_i_Cell_Min_Temperature;
}

void C_Cell_Temperature::seti_Cell_Min_Temperature(int newi_Cell_Min_Temperature)
{
    if (m_i_Cell_Min_Temperature == newi_Cell_Min_Temperature)
        return;
    m_i_Cell_Min_Temperature = newi_Cell_Min_Temperature;
    emit i_Cell_Min_TemperatureChanged();
}
