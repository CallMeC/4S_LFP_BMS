#ifndef C_CELLOVERVIEW_H
#define C_CELLOVERVIEW_H

#include <QObject>

class C_CellOverview : public QObject
{
    Q_OBJECT
    Q_PROPERTY(int i_CellBalancingMask READ i_CellBalancingMask WRITE seti_CellBalancingMask NOTIFY i_CellBalancingMaskChanged FINAL)
    Q_PROPERTY(int i_CellDeltaU READ i_CellDeltaU WRITE seti_CellDeltaU NOTIFY i_CellDeltaUChanged FINAL)
public:
    explicit C_CellOverview(QObject *parent = nullptr);

    int i_CellBalancingMask() const;
    void seti_CellBalancingMask(int newi_CellBalancingMask);

    int i_CellDeltaU() const;
    void seti_CellDeltaU(int newi_CellDeltaU);

signals:

    void i_CellBalancingMaskChanged();
    void i_CellDeltaUChanged();

private:
    int m_i_CellBalancingMask;
    int m_i_CellDeltaU;
};

#endif // C_CELLOVERVIEW_H
