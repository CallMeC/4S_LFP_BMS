#ifndef C_CELL_ALARMS_N1_H
#define C_CELL_ALARMS_N1_H

#include <QObject>

class C_Cell_Alarms_N1 : public QObject
{
    Q_OBJECT
    Q_PROPERTY(bool b_Alarm_0 READ b_Alarm_0 WRITE setb_Alarm_0 NOTIFY b_Alarm_0Changed FINAL)
    Q_PROPERTY(bool b_Alarm_1 READ b_Alarm_1 WRITE setb_Alarm_1 NOTIFY b_Alarm_1Changed FINAL)
    Q_PROPERTY(bool b_Alarm_2 READ b_Alarm_2 WRITE setb_Alarm_2 NOTIFY b_Alarm_2Changed FINAL)
    Q_PROPERTY(bool b_Alarm_3 READ b_Alarm_3 WRITE setb_Alarm_3 NOTIFY b_Alarm_3Changed FINAL)
    Q_PROPERTY(bool b_Alarm_4 READ b_Alarm_4 WRITE setb_Alarm_4 NOTIFY b_Alarm_4Changed FINAL)

public:
    explicit C_Cell_Alarms_N1(QObject *parent = nullptr);

    bool b_Alarm_0() const;
    void setb_Alarm_0(bool newb_Alarm_0);

    bool b_Alarm_1() const;
    void setb_Alarm_1(bool newb_Alarm_1);

    bool b_Alarm_2() const;
    void setb_Alarm_2(bool newb_Alarm_2);

    bool b_Alarm_3() const;
    void setb_Alarm_3(bool newb_Alarm_3);

    bool b_Alarm_4() const;
    void setb_Alarm_4(bool newb_Alarm_4);

    Q_INVOKABLE void clearN1();

signals:

    void b_Alarm_0Changed();

    void b_Alarm_1Changed();

    void b_Alarm_2Changed();

    void b_Alarm_3Changed();

    void b_Alarm_4Changed();

private:
    bool m_b_Alarm_0;
    bool m_b_Alarm_1;
    bool m_b_Alarm_2;
    bool m_b_Alarm_3;
    bool m_b_Alarm_4;
};

#endif // C_CELL_ALARMS_N1_H
