#include "C_SerialPortManager.h"
#include <QDebug>

C_SerialPortManager::C_SerialPortManager(QObject *parent)
    : QObject{parent}
{
    comPort = new QSerialPort(parent);
    qDebug() << (serialPortInit(comPort) == true ? "init Success" : " init Failure");
}

bool C_SerialPortManager::serialPortInit(QSerialPort * comPort)
{
    bool BMS_IS_AVAILIABLE = false;
    //
    //  For each available serial port
    foreach(const QSerialPortInfo &serialPortInfo, QSerialPortInfo::availablePorts())
    {
        BMS_IS_AVAILIABLE = true; //    BMS is available on this port
        BMS_PORT_NAME = serialPortInfo.portName();
    }
    if(BMS_IS_AVAILIABLE)
    {
        qDebug() << "Found the port : " << BMS_PORT_NAME;

        comPort->setPortName(BMS_PORT_NAME);
        comPort->setBaudRate(QSerialPort::Baud115200);
        comPort->setDataBits(QSerialPort::Data8);
        comPort->setFlowControl(QSerialPort::NoFlowControl);
        comPort->setParity(QSerialPort::NoParity);
        comPort->setStopBits(QSerialPort::OneStop);
        if (!(comPort->open(QIODevice::ReadWrite)))
        {
            qDebug() << "Error String : "<< comPort->errorString();
            return(false);
        }
        comPort->setDataTerminalReady(true);

        qDebug() << "Connect Signal Slot :" << QObject::connect(comPort, SIGNAL(readyRead()), this, SLOT(readSerial()));
    }
    else
    {
        qDebug() << "Couldn't find the correct port.";
        timedOutSerial();
        return(false);
    }
    parsingInProgress = false; parsingAttempts = 0;
    connect(&timerTimeoutSerial, &QTimer::timeout, [&](){timedOutSerial();});
    timerTimeoutSerial.start(500);
    return(true);
}

void C_SerialPortManager::sendCommand(unsigned char command[])
{
    QByteArray temp = QByteArray::fromRawData(reinterpret_cast<const char*>(command), COMMAND_LENGTH);
    qDebug() << "Sending : " << temp.toHex();
    comPort->write(temp, COMMAND_LENGTH);
    comPort->waitForBytesWritten(5);    //Attente 5ms max
    qDebug() << "Sent";
}

void C_SerialPortManager::timedOutSerial()
{
    if (parsingInProgress == false)
        parsingAttempts++;
    if (parsingAttempts > 5)
    {
        qDebug() << "Port disconnected.";
        VCell1 = 0; VCell2 = 0; VCell3 = 0; VCell4 = 0;
        VCellMax = 0; VCellMin = 0;
        TCell1 = 0; TCell2 = 0; TCell3 = 0; TCell4 = 0;
        TCellMax = 0; TCellMin = 0;
        SoCCell1 = 0; SoCCell2 = 0; SoCCell3 = 0; SoCCell4 = 0;
        SoCCellMax = 0; SoCCellMin = 0;
        SoHCell1 = 0; SoHCell2 = 0; SoHCell3 = 0; SoHCell4 = 0;
        SoHCellMax = 0; SoHCellMin = 0;
        VPACK = 0; IPACK = 0; SoCPACK = 0; SoHPACK = 0;
        alarmN1 = 0; alarmN2 = 0; alarmN3 = 0; shuntValue = 0;
        IMDValue = 0; IMRValue = 0; IMCValue = 0; packState = 0;
        comPort->close();
        if (serialPortInit(comPort) == true)
        {
            parsingAttempts = 0;
            qDebug() << "Success";
        }
    }
}

void C_SerialPortManager::readSerial()
{
    //qDebug() << "Read";
    serialBuffer = "";
    serialData = comPort->readAll();
    parsingInProgress = true;
    serialBuffer = serialData;
    serialData.clear();

    QStringList buffer_split = serialBuffer.split("W"); //  split the serialBuffer string, parsing with ',' as the separator
    //qDebug() << "Buffer Length : " << buffer_split.length() << "\n";
    if (buffer_split.length() != 0)  //Frame received
    {
        //qDebug() << "Buffer : " << buffer_split[0] << "\n";
        QStringList data_split = buffer_split[0].split(";");
        //qDebug() << "Length : " << data_split.length();
        if (data_split.length() < FRAME_EXPECTED_LENGTH)
        {
            qDebug() << data_split;
            return;
        }
        if (data_split[0].toUInt() > 1000)
        {
            VCell1 = data_split[0].toUInt();
            VCell1 = VCell1/1000;
        }
        //qDebug() << "VCell1" << VCell1;
        VCell2 = data_split[1].toUInt();
        VCell2 = VCell2/1000;
        VCell3 = data_split[2].toUInt();
        VCell3 = VCell3/1000;
        VCell4 = data_split[3].toUInt();
        VCell4 = VCell4/1000;
        VCellMax = data_split[4].toUInt()+1;
        VCellMin = data_split[5].toUInt()+1;

        TCell1 = data_split[6].toUInt();
        TCell1 = (TCell1 - 1000)/10;
        TCell2 = data_split[7].toUInt();
        TCell2 = (TCell2 - 1000)/10;
        TCell3 = data_split[8].toUInt();
        TCell3 = (TCell3 - 1000)/10;
        TCell4 = data_split[9].toUInt();
        TCell4 = (TCell4 - 1000)/10;
        TCellMax = data_split[10].toUInt()+1;
        TCellMin = data_split[11].toUInt()+1;

        SoCCell1 = data_split[12].toUInt();
        SoCCell1 = SoCCell1 / 10;
        SoCCell2 = data_split[13].toUInt();
        SoCCell2 = SoCCell2 / 10;
        SoCCell3 = data_split[14].toUInt();
        SoCCell3 = SoCCell3 / 10;
        SoCCell4 = data_split[15].toUInt();
        SoCCell4 = SoCCell4 / 10;
        SoCCellMax = data_split[16].toUInt();
        SoCCellMin = data_split[17].toUInt();

        SoHCell1 = data_split[18].toUInt();
        SoHCell1 = SoHCell1 / 10;
        SoHCell2 = data_split[19].toUInt();
        SoHCell2 = SoHCell2 / 10;
        SoHCell3 = data_split[20].toUInt();
        SoHCell3 = SoHCell3 / 10;
        SoHCell4 = data_split[21].toUInt();
        SoHCell4 = SoHCell4 / 10;
        SoHCellMax = data_split[22].toUInt();
        SoHCellMin = data_split[23].toUInt();

        VPACK = data_split[24].toUInt();
        VPACK = VPACK / 1000;
        IPACK = data_split[25].toUInt();
        IPACK = IPACK / 100;
        SoCPACK = data_split[26].toUInt();
        SoCPACK = SoCPACK / 10;
        SoHPACK = data_split[27].toUInt();
        SoHPACK = SoHPACK / 10;

        alarmN1 = data_split[28].toUInt();
        alarmN2 = data_split[29].toUInt();
        alarmN3 = data_split[30].toUInt();

        shuntValue = data_split[31].toUInt();

        IMDValue = data_split[32].toUInt();
        IMRValue = data_split[33].toUInt();
        IMCValue = data_split[34].toUInt();
        packState = data_split[35].toUInt();

        balancingState = data_split[36].toUInt();
        SERIAL_NUMBER = data_split[37].toUInt();

        parsingInProgress = false;
        parsingAttempts = 0;
    }
}
