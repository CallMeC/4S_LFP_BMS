#ifndef C_SERIALUPDATER_H
#define C_SERIALUPDATER_H

#include <QObject>

#include <Controllers/C_Cell_Voltage.h>
#include <Controllers/C_Cell_Temperature.h>
#include <Controllers/C_Cell_SoC.h>
#include <Controllers/C_Cell_Alarms_N1.h>
#include <Controllers/C_Cell_Alarms_N2.h>
#include <Controllers/C_Cell_Alarms_N3.h>
#include <Controllers/C_Pack_Summary.h>
#include <Controllers/C_SerialPortManager.h>
#include <Controllers/C_Settings.h>
#include <Controllers/C_CellOverview.h>

#define COMMAND_PADDING     0x00    //0
#define COMMAND_ENDCHAR     0x0D   //'\n'

#define COMMAND_PARAM_ALARM 0x21    //'!'
#define COMMAND_ALARM_N1    0x31    //'1'
#define COMMAND_ALARM_N2    0x32    //'2'
#define COMMAND_ALARM_N3    0x33    //'3'
#define COMMAND_ALARM_ALL   0x52    //'R'

#define COMMAND_PARAM_SHUNT 0x22    //''
#define COMMAND_PARAM_SN    0x23    //''
#define COMMAND_PARAM_VERB  0x24    //''
#define COMMAND_PARAM_BALA  0x26    //''


class C_SerialUpdater : public QObject
{
    Q_OBJECT
    C_SerialPortManager m_serialPortManager;

public:
    explicit C_SerialUpdater(QObject *parent = nullptr);

    void updateQML(C_Cell_Voltage &m_cellVoltageHandler,
                   C_Cell_Temperature &m_cellTemperatureHandler,
                   C_Cell_SoC &m_cellSoCHandler,
                   C_Cell_Alarms_N1 &m_cellAlarmN1Handler,
                   C_Cell_Alarms_N2 &m_cellAlarmN2Handler,
                   C_Cell_Alarms_N3 &m_cellAlarmN3Handler,
                   C_Pack_Summary &m_packSummaryHandler,
                   C_Settings &m_settingsHandler,
                   C_CellOverview &m_cellOverview);

    Q_INVOKABLE void clearN1();
    Q_INVOKABLE void clearN2();
    Q_INVOKABLE void clearN3();
    Q_INVOKABLE void clearAll();
    Q_INVOKABLE void updateSN(uint32_t newSN);
    Q_INVOKABLE void updateShunt(uint16_t newShuntValue);
    Q_INVOKABLE void enableVerbose();
    Q_INVOKABLE void toggleBalancing();
signals:

};

#endif // C_SERIALUPDATER_H
