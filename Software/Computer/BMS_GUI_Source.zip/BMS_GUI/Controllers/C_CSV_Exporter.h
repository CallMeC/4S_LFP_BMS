#ifndef C_CSV_EXPORTER_H
#define C_CSV_EXPORTER_H

#include <QObject>
#include <QVector>
#include <QPointF>
#include <QVariant>
#include <QJsonArray>

class QLineSeries;
class QScatterSeries;

class C_CSV_Exporter : public QObject
{
    Q_OBJECT
public:
    explicit C_CSV_Exporter(QObject *parent = nullptr);

    Q_INVOKABLE void exportToCsv(const QString &fileName, const QStringList &headers, const QList<QJsonArray>& data);
    Q_INVOKABLE QJsonArray getSeriesData(QObject *seriesObject);

signals:
    void exportFinished(bool success);

};

#endif // C_CSV_EXPORTER_H
