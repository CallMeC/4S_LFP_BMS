#include "C_Cell_SoC.h"

C_Cell_SoC::C_Cell_SoC(QObject *parent)
    : QObject{parent}
    , m_i_Cell_1_SoC{DEFAULT_SOC}
    , m_i_Cell_2_SoC{DEFAULT_SOC}
    , m_i_Cell_3_SoC{DEFAULT_SOC}
    , m_i_Cell_4_SoC{DEFAULT_SOC}
{

}

int C_Cell_SoC::i_Cell_1_SoC() const
{
    return m_i_Cell_1_SoC;
}

void C_Cell_SoC::seti_Cell_1_SoC(int newi_Cell_1_SoC)
{
    if (m_i_Cell_1_SoC == newi_Cell_1_SoC)
        return;
    m_i_Cell_1_SoC = newi_Cell_1_SoC;
    emit i_Cell_1_SoCChanged();
}

int C_Cell_SoC::i_Cell_2_SoC() const
{
    return m_i_Cell_2_SoC;
}

void C_Cell_SoC::seti_Cell_2_SoC(int newi_Cell_2_SoC)
{
    if (m_i_Cell_2_SoC == newi_Cell_2_SoC)
        return;
    m_i_Cell_2_SoC = newi_Cell_2_SoC;
    emit i_Cell_2_SoCChanged();
}

int C_Cell_SoC::i_Cell_3_SoC() const
{
    return m_i_Cell_3_SoC;
}

void C_Cell_SoC::seti_Cell_3_SoC(int newi_Cell_3_SoC)
{
    if (m_i_Cell_3_SoC == newi_Cell_3_SoC)
        return;
    m_i_Cell_3_SoC = newi_Cell_3_SoC;
    emit i_Cell_3_SoCChanged();
}

int C_Cell_SoC::i_Cell_4_SoC() const
{
    return m_i_Cell_4_SoC;
}

void C_Cell_SoC::seti_Cell_4_SoC(int newi_Cell_4_SoC)
{
    if (m_i_Cell_4_SoC == newi_Cell_4_SoC)
        return;
    m_i_Cell_4_SoC = newi_Cell_4_SoC;
    emit i_Cell_4_SoCChanged();
}
