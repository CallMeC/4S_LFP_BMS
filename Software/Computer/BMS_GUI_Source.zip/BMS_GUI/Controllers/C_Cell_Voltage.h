#ifndef C_CELL_VOLTAGE_H
#define C_CELL_VOLTAGE_H

#include <QObject>

#define DEFAULT_VOLTAGE 3.2
#define DEFAULT_MIN_MAX 0

class C_Cell_Voltage : public QObject
{
    Q_OBJECT
    Q_PROPERTY(float f_Cell_1_Voltage READ f_Cell_1_Voltage WRITE setf_Cell_1_Voltage NOTIFY f_Cell_1_VoltageChanged FINAL)
    Q_PROPERTY(float f_Cell_2_Voltage READ f_Cell_2_Voltage WRITE setf_Cell_2_Voltage NOTIFY f_Cell_2_VoltageChanged FINAL)
    Q_PROPERTY(float f_Cell_3_Voltage READ f_Cell_3_Voltage WRITE setf_Cell_3_Voltage NOTIFY f_Cell_3_VoltageChanged FINAL)
    Q_PROPERTY(float f_Cell_4_Voltage READ f_Cell_4_Voltage WRITE setf_Cell_4_Voltage NOTIFY f_Cell_4_VoltageChanged FINAL)
    Q_PROPERTY(int i_Cell_Max_Voltage READ i_Cell_Max_Voltage WRITE seti_Cell_Max_Voltage NOTIFY i_Cell_Max_VoltageChanged FINAL)
    Q_PROPERTY(int i_Cell_Min_Voltage READ i_Cell_Min_Voltage WRITE seti_Cell_Min_Voltage NOTIFY i_Cell_Min_VoltageChanged FINAL)

public:
    explicit C_Cell_Voltage(QObject *parent = nullptr);


    float f_Cell_1_Voltage() const;
    void setf_Cell_1_Voltage(float newf_Cell_1_Voltage);

    float f_Cell_2_Voltage() const;
    void setf_Cell_2_Voltage(float newf_Cell_2_Voltage);

    float f_Cell_3_Voltage() const;
    void setf_Cell_3_Voltage(float newf_Cell_3_Voltage);

    float f_Cell_4_Voltage() const;
    void setf_Cell_4_Voltage(float newf_Cell_4_Voltage);

    int i_Cell_Max_Voltage() const;
    void seti_Cell_Max_Voltage(int newi_Cell_Max_Voltage);

    int i_Cell_Min_Voltage() const;
    void seti_Cell_Min_Voltage(int newi_Cell_Min_Voltage);

signals:

    void f_Cell_1_VoltageChanged();

    void f_Cell_2_VoltageChanged();

    void f_Cell_3_VoltageChanged();

    void f_Cell_4_VoltageChanged();

    void i_Cell_Max_VoltageChanged();

    void i_Cell_Min_VoltageChanged();

private:
    float m_f_Cell_1_Voltage;
    float m_f_Cell_2_Voltage;
    float m_f_Cell_3_Voltage;
    float m_f_Cell_4_Voltage;
    int m_i_Cell_Max_Voltage;
    int m_i_Cell_Min_Voltage;
};

#endif // C_CELL_VOLTAGE_H
