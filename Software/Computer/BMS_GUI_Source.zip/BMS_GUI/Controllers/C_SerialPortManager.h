#ifndef C_SERIALPORTMANAGER_H
#define C_SERIALPORTMANAGER_H

#include <QObject>
#include <QTimer>
#include <QtSerialPort/QSerialPort>
#include <QtSerialPort/QSerialPortInfo>

#define FRAME_EXPECTED_LENGTH 38
#define COMMAND_LENGTH 8

class C_SerialPortManager : public QObject
{
    Q_OBJECT
public:
    explicit C_SerialPortManager(QObject *parent = nullptr);
    float VCell1, VCell2, VCell3, VCell4;
    uint8_t VCellMax, VCellMin;
    float TCell1, TCell2, TCell3, TCell4;
    uint8_t TCellMax, TCellMin;
    float SoCCell1, SoCCell2, SoCCell3, SoCCell4;
    uint8_t SoCCellMax, SoCCellMin;
    float SoHCell1, SoHCell2, SoHCell3, SoHCell4;
    uint8_t SoHCellMax, SoHCellMin;
    float VPACK, IPACK, SoCPACK, SoHPACK;
    uint8_t alarmN1, alarmN2, alarmN3;
    uint16_t shuntValue;
    uint16_t IMDValue, IMRValue, IMCValue;
    uint8_t packState;
    uint8_t balancingState;
    uint32_t SERIAL_NUMBER;
    void sendCommand(unsigned char command[COMMAND_LENGTH]);
    bool serialPortInit(QSerialPort *comPort);

signals:

private slots:
    void readSerial();

private:
    QSerialPort *comPort;
    QString BMS_PORT_NAME;
    QByteArray serialData;
    QString serialBuffer;
    QTimer timerTimeoutSerial;
    void timedOutSerial();

    bool parsingInProgress;
    uint8_t parsingAttempts;
};

#endif // C_SERIALPORTMANAGER_H
