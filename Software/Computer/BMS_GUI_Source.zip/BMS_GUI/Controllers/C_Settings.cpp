#include "C_Settings.h"

C_Settings::C_Settings(QObject *parent)
    : QObject{parent}
    , m_i_BMS_ShuntResistor{DEFAULT_SHUNT}
{

}

int C_Settings::i_BMS_ShuntResistor() const
{
    return m_i_BMS_ShuntResistor;
}

void C_Settings::seti_BMS_ShuntResistor(int newi_BMS_ShuntResistor)
{
    if (m_i_BMS_ShuntResistor == newi_BMS_ShuntResistor)
        return;
    m_i_BMS_ShuntResistor = newi_BMS_ShuntResistor;
    emit i_BMS_ShuntResistorChanged();
}

int C_Settings::i_BMS_SERIAL_NUMBER() const
{
    return m_i_BMS_SERIAL_NUMBER;
}

void C_Settings::seti_BMS_SERIAL_NUMBER(int newi_BMS_SERIAL_NUMBER)
{
    if (m_i_BMS_SERIAL_NUMBER == newi_BMS_SERIAL_NUMBER)
        return;
    m_i_BMS_SERIAL_NUMBER = newi_BMS_SERIAL_NUMBER;
    emit i_BMS_SERIAL_NUMBERChanged();
}
