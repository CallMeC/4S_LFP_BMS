#include "C_CSV_Exporter.h"
#include <QFile>
#include <QTextStream>
#include <QDebug>
#include <QLineSeries>
#include <QScatterSeries>
#include <QList>
#include <QJsonObject>
#include <QJsonArray>
#include <QJsonDocument>

C_CSV_Exporter::C_CSV_Exporter(QObject *parent)
    : QObject{parent}
{

}

void C_CSV_Exporter::exportToCsv(const QString &fileName, const QStringList &headers, const QList<QJsonArray>& data)
{
    QFile file(fileName);
    if (!file.open(QIODevice::WriteOnly | QIODevice::Text))
    {
        emit exportFinished(false);
        return;
    }

    QTextStream out(&file);
    out << headers.join(",") << "\n";
    int seriesNumber = data.length();
    int maxLength = 0;
    for (const auto &seriesData : data)
    {
        if (seriesData.size() > maxLength)
            maxLength = seriesData.size();
    }
    //qDebug() << "Max length : " << maxLength;

    for (int i = 0; i < maxLength; ++i)
    {
        QStringList row;
        int xadded = 0;
        for (const auto &seriesData : data)
        {
            if (i < seriesData.size())
            {
                const QJsonObject point = seriesData[i].toObject();
                if (seriesNumber == 1)
                    row << QString::number(point["x"].toDouble()) << QString::number(point["y"].toDouble());
                else
                {
                    if (xadded == 0)
                    {
                        row << QString::number(point["x"].toDouble()) << QString::number(point["y"].toDouble());
                        xadded = 1;
                    }
                    else
                        row << QString::number(point["y"].toDouble());
                }
            }
            else
            {
                row << "" << "";
            }
        }
        out << row.join(",") << "\n";
    }

    file.close();
    emit exportFinished(true);
}


QJsonArray C_CSV_Exporter::getSeriesData(QObject *seriesObject)
{
    QJsonArray result;

    if (auto *series = qobject_cast<QLineSeries*>(seriesObject))
    {
        const auto points = series->points();
        for (const QPointF &point : points)
        {
            QJsonObject pointData;
            pointData["x"] = point.x();
            pointData["y"] = point.y();
            result.append(pointData);
        }
    }
    else
    {
        qDebug() << "Error, wrong type of series";
    }

    return result;
}

