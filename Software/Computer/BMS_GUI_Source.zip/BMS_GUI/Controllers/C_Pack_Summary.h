#ifndef C_PACK_SUMMARY_H
#define C_PACK_SUMMARY_H

#include <QObject>

#define DEFAULT_VOLTAGE     12.69
#define DEFAULT_CURRENT     140.2
#define DEFAULT_SOH         97.8
#define DEFAULT_SOC         19.2
#define DEFAULT_IMD         50
#define DEFAULT_IMR         50
#define DEFAULT_IMC         50
#define DEFAULT_PACK_STATE  0

class C_Pack_Summary : public QObject
{
    Q_OBJECT
    Q_PROPERTY(float f_Pack_Voltage READ f_Pack_Voltage WRITE setf_Pack_Voltage NOTIFY f_Pack_VoltageChanged FINAL)
    Q_PROPERTY(float f_Pack_Current READ f_Pack_Current WRITE setf_Pack_Current NOTIFY f_Pack_CurrentChanged FINAL)
    Q_PROPERTY(float f_Pack_SoH READ f_Pack_SoH WRITE setf_Pack_SoH NOTIFY f_Pack_SoHChanged FINAL)
    Q_PROPERTY(float f_Pack_SoC READ f_Pack_SoC WRITE setf_Pack_SoC NOTIFY f_Pack_SoCChanged FINAL)
    Q_PROPERTY(float f_Pack_IMD READ f_Pack_IMD WRITE setf_Pack_IMD NOTIFY f_Pack_IMDChanged FINAL)
    Q_PROPERTY(float f_Pack_IMR READ f_Pack_IMR WRITE setf_Pack_IMR NOTIFY f_Pack_IMRChanged FINAL)
    Q_PROPERTY(float f_Pack_IMC READ f_Pack_IMC WRITE setf_Pack_IMC NOTIFY f_Pack_IMCChanged FINAL)
    Q_PROPERTY(float f_packState READ f_packState WRITE setf_packState NOTIFY f_packStateChanged FINAL)
public:
    explicit C_Pack_Summary(QObject *parent = nullptr);

    float f_Pack_Voltage() const;
    void setf_Pack_Voltage(float newf_Pack_Voltage);

    float f_Pack_Current() const;
    void setf_Pack_Current(float newf_Pack_Current);

    float f_Pack_SoH() const;
    void setf_Pack_SoH(float newf_Pack_SoH);

    float f_Pack_SoC() const;
    void setf_Pack_SoC(float newf_Pack_SoC);

    float f_Pack_IMD() const;
    void setf_Pack_IMD(float newf_Pack_IMD);

    float f_Pack_IMR() const;
    void setf_Pack_IMR(float newF_Pack_IMR);

    float f_Pack_IMC() const;
    void setf_Pack_IMC(float newF_Pack_IMC);

    float f_packState() const;
    void setf_packState(float newf_packState);

signals:

    void f_Pack_VoltageChanged();
    void f_Pack_CurrentChanged();

    void f_Pack_SoHChanged();

    void f_Pack_SoCChanged();

    void f_Pack_IMDChanged();

    void f_Pack_IMRChanged();

    void f_Pack_IMCChanged();

    void f_packStateChanged();

private:
    float m_f_Pack_Voltage;
    float m_f_Pack_Current;
    float m_f_Pack_SoH;
    float m_f_Pack_SoC;
    float m_f_Pack_IMD;
    float m_f_Pack_IMR;
    float m_f_Pack_IMC;
    float m_f_packState;
};

#endif // C_PACK_SUMMARY_H
