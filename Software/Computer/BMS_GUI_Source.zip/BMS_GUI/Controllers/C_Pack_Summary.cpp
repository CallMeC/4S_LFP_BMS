#include "C_Pack_Summary.h"

C_Pack_Summary::C_Pack_Summary(QObject *parent)
    : QObject{parent}
    , m_f_Pack_Voltage{DEFAULT_VOLTAGE}
    , m_f_Pack_Current{DEFAULT_CURRENT}
    , m_f_Pack_SoH{DEFAULT_SOH}
    , m_f_Pack_SoC{DEFAULT_SOC}
    , m_f_Pack_IMD{DEFAULT_IMD}
    , m_f_Pack_IMR{DEFAULT_IMR}
    , m_f_Pack_IMC{DEFAULT_IMC}
    , m_f_packState{DEFAULT_PACK_STATE}
{

}

float C_Pack_Summary::f_Pack_Voltage() const
{
    return m_f_Pack_Voltage;
}

void C_Pack_Summary::setf_Pack_Voltage(float newf_Pack_Voltage)
{
    if (qFuzzyCompare(m_f_Pack_Voltage, newf_Pack_Voltage))
        return;
    m_f_Pack_Voltage = newf_Pack_Voltage;
    emit f_Pack_VoltageChanged();
}

float C_Pack_Summary::f_Pack_Current() const
{
    return m_f_Pack_Current;
}

void C_Pack_Summary::setf_Pack_Current(float newf_Pack_Current)
{
    if (qFuzzyCompare(m_f_Pack_Current, newf_Pack_Current))
        return;
    m_f_Pack_Current = newf_Pack_Current;
    emit f_Pack_CurrentChanged();
}

float C_Pack_Summary::f_Pack_SoH() const
{
    return m_f_Pack_SoH;
}

void C_Pack_Summary::setf_Pack_SoH(float newf_Pack_SoH)
{
    if (qFuzzyCompare(m_f_Pack_SoH, newf_Pack_SoH))
        return;
    m_f_Pack_SoH = newf_Pack_SoH;
    emit f_Pack_SoHChanged();
}

float C_Pack_Summary::f_Pack_SoC() const
{
    return m_f_Pack_SoC;
}

void C_Pack_Summary::setf_Pack_SoC(float newf_Pack_SoC)
{
    if (qFuzzyCompare(m_f_Pack_SoC, newf_Pack_SoC))
        return;
    m_f_Pack_SoC = newf_Pack_SoC;
    emit f_Pack_SoCChanged();
}

float C_Pack_Summary::f_Pack_IMD() const
{
    return m_f_Pack_IMD;
}

void C_Pack_Summary::setf_Pack_IMD(float newf_Pack_IMD)
{
    if (qFuzzyCompare(m_f_Pack_IMD, newf_Pack_IMD))
        return;
    m_f_Pack_IMD = newf_Pack_IMD;
    emit f_Pack_IMDChanged();
}

float C_Pack_Summary::f_Pack_IMR() const
{
    return m_f_Pack_IMR;
}

void C_Pack_Summary::setf_Pack_IMR(float newf_Pack_IMR)
{
    if (qFuzzyCompare(m_f_Pack_IMR, newf_Pack_IMR))
        return;
    m_f_Pack_IMR = newf_Pack_IMR;
    emit f_Pack_IMRChanged();
}

float C_Pack_Summary::f_Pack_IMC() const
{
    return m_f_Pack_IMC;
}

void C_Pack_Summary::setf_Pack_IMC(float newf_Pack_IMC)
{
    if (qFuzzyCompare(m_f_Pack_IMC, newf_Pack_IMC))
        return;
    m_f_Pack_IMC = newf_Pack_IMC;
    emit f_Pack_IMCChanged();
}

float C_Pack_Summary::f_packState() const
{
    return m_f_packState;
}

void C_Pack_Summary::setf_packState(float newf_packState)
{
    if (qFuzzyCompare(m_f_packState, newf_packState))
        return;
    m_f_packState = newf_packState;
    emit f_packStateChanged();
}
