#ifndef C_CELL_SOC_H
#define C_CELL_SOC_H

#include <QObject>

#define DEFAULT_SOC 48

class C_Cell_SoC : public QObject
{
    Q_OBJECT
    Q_PROPERTY(int i_Cell_1_SoC READ i_Cell_1_SoC WRITE seti_Cell_1_SoC NOTIFY i_Cell_1_SoCChanged FINAL)
    Q_PROPERTY(int i_Cell_2_SoC READ i_Cell_2_SoC WRITE seti_Cell_2_SoC NOTIFY i_Cell_2_SoCChanged FINAL)
    Q_PROPERTY(int i_Cell_3_SoC READ i_Cell_3_SoC WRITE seti_Cell_3_SoC NOTIFY i_Cell_3_SoCChanged FINAL)
    Q_PROPERTY(int i_Cell_4_SoC READ i_Cell_4_SoC WRITE seti_Cell_4_SoC NOTIFY i_Cell_4_SoCChanged FINAL)

public:
    explicit C_Cell_SoC(QObject *parent = nullptr);

    int i_Cell_1_SoC() const;
    void seti_Cell_1_SoC(int newi_Cell_1_SoC);

    int i_Cell_2_SoC() const;
    void seti_Cell_2_SoC(int newi_Cell_2_SoC);

    int i_Cell_3_SoC() const;
    void seti_Cell_3_SoC(int newi_Cell_3_SoC);

    int i_Cell_4_SoC() const;
    void seti_Cell_4_SoC(int newi_Cell_4_SoC);

signals:

    void i_Cell_1_SoCChanged();
    void i_Cell_2_SoCChanged();

    void i_Cell_3_SoCChanged();

    void i_Cell_4_SoCChanged();

private:
    int m_i_Cell_1_SoC;
    int m_i_Cell_2_SoC;
    int m_i_Cell_3_SoC;
    int m_i_Cell_4_SoC;
};

#endif // C_CELL_SOC_H
