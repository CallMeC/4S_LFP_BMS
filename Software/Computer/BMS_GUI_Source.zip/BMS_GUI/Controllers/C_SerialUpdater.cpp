#include "C_SerialUpdater.h"
#include <QDebug>

C_SerialUpdater::C_SerialUpdater(QObject *parent)
    : QObject{parent}
{
    enableVerbose();
}


void C_SerialUpdater::updateQML(C_Cell_Voltage &m_cellVoltageHandler,
                                C_Cell_Temperature &m_cellTemperatureHandler,
                                C_Cell_SoC &m_cellSoCHandler,
                                C_Cell_Alarms_N1 &m_cellAlarmN1Handler,
                                C_Cell_Alarms_N2 &m_cellAlarmN2Handler,
                                C_Cell_Alarms_N3 &m_cellAlarmN3Handler,
                                C_Pack_Summary &m_packSummaryHandler,
                                C_Settings &m_settingsHandler,
                                C_CellOverview &m_cellOverviewHandler)
{
    m_cellVoltageHandler.setf_Cell_1_Voltage(m_serialPortManager.VCell1);
    m_cellVoltageHandler.setf_Cell_2_Voltage(m_serialPortManager.VCell2);
    m_cellVoltageHandler.setf_Cell_3_Voltage(m_serialPortManager.VCell3);
    m_cellVoltageHandler.setf_Cell_4_Voltage(m_serialPortManager.VCell4);
    m_cellVoltageHandler.seti_Cell_Min_Voltage(m_serialPortManager.VCellMin);
    m_cellVoltageHandler.seti_Cell_Max_Voltage(m_serialPortManager.VCellMax);

    m_cellTemperatureHandler.setf_Cell_1_Temperature(m_serialPortManager.TCell1);
    m_cellTemperatureHandler.setf_Cell_2_Temperature(m_serialPortManager.TCell2);
    m_cellTemperatureHandler.setf_Cell_3_Temperature(m_serialPortManager.TCell3);
    m_cellTemperatureHandler.setf_Cell_4_Temperature(m_serialPortManager.TCell4);
    m_cellTemperatureHandler.seti_Cell_Max_Temperature(m_serialPortManager.TCellMax);
    m_cellTemperatureHandler.seti_Cell_Min_Temperature(m_serialPortManager.TCellMin);

    m_cellSoCHandler.seti_Cell_1_SoC(m_serialPortManager.SoCCell1);
    m_cellSoCHandler.seti_Cell_2_SoC(m_serialPortManager.SoCCell2);
    m_cellSoCHandler.seti_Cell_3_SoC(m_serialPortManager.SoCCell3);
    m_cellSoCHandler.seti_Cell_4_SoC(m_serialPortManager.SoCCell4);

    m_packSummaryHandler.setf_Pack_Voltage(m_serialPortManager.VPACK);
    m_packSummaryHandler.setf_Pack_Current(m_serialPortManager.IPACK);
    m_packSummaryHandler.setf_Pack_SoC(m_serialPortManager.SoCPACK);
    m_packSummaryHandler.setf_Pack_SoH(m_serialPortManager.SoHPACK);
    m_packSummaryHandler.setf_Pack_IMD(m_serialPortManager.IMDValue);
    m_packSummaryHandler.setf_Pack_IMR(m_serialPortManager.IMRValue);
    m_packSummaryHandler.setf_Pack_IMC(m_serialPortManager.IMCValue);
    m_packSummaryHandler.setf_packState(m_serialPortManager.packState);
    //qDebug() << "IMD IMR IMC" << m_packSummaryHandler.f_Pack_IMD() << " " <<m_packSummaryHandler.f_Pack_IMR() << " " << m_packSummaryHandler.f_Pack_IMC();

    m_cellAlarmN1Handler.setb_Alarm_0(m_serialPortManager.alarmN1&0x01);
    m_cellAlarmN1Handler.setb_Alarm_1(m_serialPortManager.alarmN1&0x02);
    m_cellAlarmN1Handler.setb_Alarm_2(m_serialPortManager.alarmN1&0x04);
    m_cellAlarmN1Handler.setb_Alarm_3(m_serialPortManager.alarmN1&0x08);
    m_cellAlarmN1Handler.setb_Alarm_4(m_serialPortManager.alarmN1&0x10);

    m_cellAlarmN2Handler.setb_Alarm_0(m_serialPortManager.alarmN2&0x01);
    m_cellAlarmN2Handler.setb_Alarm_1(m_serialPortManager.alarmN2&0x02);
    m_cellAlarmN2Handler.setb_Alarm_2(m_serialPortManager.alarmN2&0x04);
    m_cellAlarmN2Handler.setb_Alarm_3(m_serialPortManager.alarmN2&0x08);
    m_cellAlarmN2Handler.setb_Alarm_4(m_serialPortManager.alarmN2&0x10);

    m_cellAlarmN3Handler.setb_Alarm_0(m_serialPortManager.alarmN3&0x01);
    m_cellAlarmN3Handler.setb_Alarm_1(m_serialPortManager.alarmN3&0x02);
    m_cellAlarmN3Handler.setb_Alarm_2(m_serialPortManager.alarmN3&0x04);
    m_cellAlarmN3Handler.setb_Alarm_3(m_serialPortManager.alarmN3&0x08);
    m_cellAlarmN3Handler.setb_Alarm_4(m_serialPortManager.alarmN3&0x10);

    m_settingsHandler.seti_BMS_ShuntResistor(m_serialPortManager.shuntValue);
    m_settingsHandler.seti_BMS_SERIAL_NUMBER(m_serialPortManager.SERIAL_NUMBER);

    m_cellOverviewHandler.seti_CellBalancingMask(m_serialPortManager.balancingState);

    //Delta U Determination
    float jeepDeltaU = std::max(std::max(m_serialPortManager.VCell1, m_serialPortManager.VCell2), std::max(m_serialPortManager.VCell3, m_serialPortManager.VCell4));
    jeepDeltaU -= std::min(std::min(m_serialPortManager.VCell1, m_serialPortManager.VCell2), std::min(m_serialPortManager.VCell3, m_serialPortManager.VCell4));
    m_cellOverviewHandler.seti_CellDeltaU(jeepDeltaU*1000);
}



void C_SerialUpdater::clearN1()
{
    qDebug() << "Clear N1";
    unsigned char command[8] = {COMMAND_PARAM_ALARM, COMMAND_ALARM_N1, COMMAND_PADDING, COMMAND_PADDING, COMMAND_PADDING, COMMAND_PADDING, COMMAND_PADDING, COMMAND_ENDCHAR};
    m_serialPortManager.sendCommand(command);
}

void C_SerialUpdater::clearN2()
{
    qDebug() << "Clear N2";
    unsigned char command[8] = {COMMAND_PARAM_ALARM, COMMAND_ALARM_N2, COMMAND_PADDING, COMMAND_PADDING, COMMAND_PADDING, COMMAND_PADDING, COMMAND_PADDING, COMMAND_ENDCHAR};
    m_serialPortManager.sendCommand(command);
}

void C_SerialUpdater::clearN3()
{
    qDebug() << "Clear N3";
    unsigned char command[8] = {COMMAND_PARAM_ALARM, COMMAND_ALARM_N3, COMMAND_PADDING, COMMAND_PADDING, COMMAND_PADDING, COMMAND_PADDING, COMMAND_PADDING, COMMAND_ENDCHAR};
    m_serialPortManager.sendCommand(command);
}

void C_SerialUpdater::clearAll()
{
    qDebug() << "Clear All";
    unsigned char command[8] = {COMMAND_PARAM_ALARM, COMMAND_ALARM_ALL, COMMAND_PADDING, COMMAND_PADDING, COMMAND_PADDING, COMMAND_PADDING, COMMAND_PADDING, COMMAND_ENDCHAR};
    m_serialPortManager.sendCommand(command);
}

void C_SerialUpdater::updateSN(uint32_t newSN)
{
    qDebug() << "New SN : " << newSN;
    uint8_t byte1 = (newSN >> 24) & 0xFF;
    uint8_t byte2 = (newSN >> 16) & 0xFF;
    uint8_t byte3 = (newSN >> 8) & 0xFF;
    uint8_t byte4 = newSN & 0xFF;
    unsigned char command[8] = {COMMAND_PARAM_SN, COMMAND_PADDING, COMMAND_PADDING, COMMAND_PADDING, COMMAND_PADDING, COMMAND_PADDING, COMMAND_PADDING, COMMAND_ENDCHAR};
    command[1] = (unsigned char)byte1; command[2] = (unsigned char)byte2; command[3] = (unsigned char)byte3; command[4] = (unsigned char)byte4;
    m_serialPortManager.sendCommand(command);
}

void C_SerialUpdater::updateShunt(uint16_t newShuntValue)
{
    qDebug() << "New Shunt : " << newShuntValue;
    uint8_t byte1 = (newShuntValue >> 8) & 0xFF;
    uint8_t byte2 = newShuntValue & 0xFF;
    unsigned char command[8] = {COMMAND_PARAM_SHUNT, COMMAND_PADDING, COMMAND_PADDING, COMMAND_PADDING, COMMAND_PADDING, COMMAND_PADDING, COMMAND_PADDING, COMMAND_ENDCHAR};
    command[1] = (unsigned char)byte1;
    command[2] = (unsigned char)byte2;

    m_serialPortManager.sendCommand(command);
}

void C_SerialUpdater::enableVerbose()
{
    qDebug() << "Verbose Enabled";
    unsigned char command[8] = {COMMAND_PARAM_VERB, COMMAND_PADDING, COMMAND_PADDING, COMMAND_PADDING, COMMAND_PADDING, COMMAND_PADDING, COMMAND_PADDING, COMMAND_ENDCHAR};
    m_serialPortManager.sendCommand(command);
}

void C_SerialUpdater::toggleBalancing()
{
    qDebug() << "Balancing Toggled";
    unsigned char command[8] = {COMMAND_PARAM_BALA, COMMAND_PADDING, COMMAND_PADDING, COMMAND_PADDING, COMMAND_PADDING, COMMAND_PADDING, COMMAND_PADDING, COMMAND_ENDCHAR};
    m_serialPortManager.sendCommand(command);
}


