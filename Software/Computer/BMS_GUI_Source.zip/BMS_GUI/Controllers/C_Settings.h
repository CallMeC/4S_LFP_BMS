#ifndef C_SETTINGS_H
#define C_SETTINGS_H

#define DEFAULT_SHUNT 100

#include <QObject>

class C_Settings : public QObject
{
    Q_OBJECT
    Q_PROPERTY(int i_BMS_ShuntResistor READ i_BMS_ShuntResistor WRITE seti_BMS_ShuntResistor NOTIFY i_BMS_ShuntResistorChanged FINAL)
    Q_PROPERTY(int i_BMS_SERIAL_NUMBER READ i_BMS_SERIAL_NUMBER WRITE seti_BMS_SERIAL_NUMBER NOTIFY i_BMS_SERIAL_NUMBERChanged FINAL)
public:
    explicit C_Settings(QObject *parent = nullptr);

    int i_BMS_ShuntResistor() const;
    void seti_BMS_ShuntResistor(int newi_BMS_ShuntResistor);

    int i_BMS_SERIAL_NUMBER() const;
    void seti_BMS_SERIAL_NUMBER(int newi_BMS_SERIAL_NUMBER);

signals:

    void i_BMS_ShuntResistorChanged();

    void i_BMS_SERIAL_NUMBERChanged();

private:

    int m_i_BMS_ShuntResistor;
    int m_i_BMS_SERIAL_NUMBER;
};

#endif // C_SETTINGS_H
