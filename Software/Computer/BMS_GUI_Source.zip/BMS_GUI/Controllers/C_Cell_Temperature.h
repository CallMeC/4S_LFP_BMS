#ifndef C_CELL_TEMPERATURE_H
#define C_CELL_TEMPERATURE_H

#include <QObject>

#define DEFAULT_TEMP 16.4
#define DEFAULT_MIN_MAX 0

class C_Cell_Temperature : public QObject
{
    Q_OBJECT
    Q_PROPERTY(float f_Cell_1_Temperature READ f_Cell_1_Temperature WRITE setf_Cell_1_Temperature NOTIFY f_Cell_1_TemperatureChanged FINAL)
    Q_PROPERTY(float f_Cell_2_Temperature READ f_Cell_2_Temperature WRITE setf_Cell_2_Temperature NOTIFY f_Cell_2_TemperatureChanged FINAL)
    Q_PROPERTY(float f_Cell_3_Temperature READ f_Cell_3_Temperature WRITE setf_Cell_3_Temperature NOTIFY f_Cell_3_TemperatureChanged FINAL)
    Q_PROPERTY(float f_Cell_4_Temperature READ f_Cell_4_Temperature WRITE setf_Cell_4_Temperature NOTIFY f_Cell_4_TemperatureChanged FINAL)
    Q_PROPERTY(int i_Cell_Max_Temperature READ i_Cell_Max_Temperature WRITE seti_Cell_Max_Temperature NOTIFY i_Cell_Max_TemperatureChanged FINAL)
    Q_PROPERTY(int i_Cell_Min_Temperature READ i_Cell_Min_Temperature WRITE seti_Cell_Min_Temperature NOTIFY i_Cell_Min_TemperatureChanged FINAL)

public:
    explicit C_Cell_Temperature(QObject *parent = nullptr);

    float f_Cell_1_Temperature() const;
    void setf_Cell_1_Temperature(float newf_Cell_1_Temperature);

    float f_Cell_2_Temperature() const;
    void setf_Cell_2_Temperature(float newf_Cell_2_Temperature);

    float f_Cell_3_Temperature() const;
    void setf_Cell_3_Temperature(float newf_Cell_3_Temperature);

    float f_Cell_4_Temperature() const;
    void setf_Cell_4_Temperature(float newf_Cell_4_Temperature);

    int i_Cell_Max_Temperature() const;
    void seti_Cell_Max_Temperature(int newi_Cell_Max_Temperature);

    int i_Cell_Min_Temperature() const;
    void seti_Cell_Min_Temperature(int newi_Cell_Min_Temperature);

signals:

    void f_Cell_1_TemperatureChanged();
    void f_Cell_2_TemperatureChanged();

    void f_Cell_3_TemperatureChanged();

    void f_Cell_4_TemperatureChanged();

    void i_Cell_Max_TemperatureChanged();

    void i_Cell_Min_TemperatureChanged();

private:
    float m_f_Cell_1_Temperature;
    float m_f_Cell_2_Temperature;
    float m_f_Cell_3_Temperature;
    float m_f_Cell_4_Temperature;
    int m_i_Cell_Max_Temperature;
    int m_i_Cell_Min_Temperature;
};

#endif // C_CELL_TEMPERATURE_H
