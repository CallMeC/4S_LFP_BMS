#include <QtWidgets/QApplication>
#include <QQmlApplicationEngine>
#include <QQmlContext>
#include <QQuickStyle>
#include <QTimer>

#include <Controllers/C_Cell_Voltage.h>
#include <Controllers/C_Cell_Temperature.h>
#include <Controllers/C_Cell_SoC.h>
#include <Controllers/C_Cell_Alarms_N1.h>
#include <Controllers/C_Cell_Alarms_N2.h>
#include <Controllers/C_Cell_Alarms_N3.h>
#include <Controllers/C_Pack_Summary.h>
#include <Controllers/C_Settings.h>
#include <Controllers/C_CellOverview.h>

#include <Controllers/C_SerialPortManager.h>
#include <Controllers/C_SerialUpdater.h>

#include <Controllers/C_CSV_Exporter.h>


int main(int argc, char *argv[])
{
    QApplication app(argc, argv);

    C_SerialUpdater m_serialUpdater;

    C_Cell_Voltage m_cellVoltageHandler;
    C_Cell_Temperature m_cellTemperatureHandler;
    C_Cell_SoC m_cellSoCHandler;
    C_Cell_Alarms_N1 m_cellAlarmN1Handler;
    C_Cell_Alarms_N2 m_cellAlarmN2Handler;
    C_Cell_Alarms_N3 m_cellAlarmN3Handler;
    C_Pack_Summary m_packSummaryHandler;
    C_Settings m_settingsHandler;
    C_CellOverview m_cellOverviewHandler;
    C_CSV_Exporter m_csvExporterHandler;

    QTimer timerUpdateQML;

    QObject::connect(&timerUpdateQML, &QTimer::timeout, [&](){m_serialUpdater.updateQML(
                                                                m_cellVoltageHandler, m_cellTemperatureHandler, m_cellSoCHandler,
                                                                m_cellAlarmN1Handler, m_cellAlarmN2Handler, m_cellAlarmN3Handler,
                                                                m_packSummaryHandler, m_settingsHandler, m_cellOverviewHandler);});

    QQmlApplicationEngine engine;

    /* Context shall be created before loading the App*/
    QQmlContext* cellVoltageContext = engine.rootContext();
    cellVoltageContext->setContextProperty("cellVoltageHandler", &m_cellVoltageHandler);

    QQmlContext* cellTemperatureContext = engine.rootContext();
    cellTemperatureContext->setContextProperty("cellTemperatureHandler", &m_cellTemperatureHandler);

    QQmlContext* cellSoCContext = engine.rootContext();
    cellSoCContext->setContextProperty("cellSoCHandler", &m_cellSoCHandler);

    QQmlContext* cellAlarmN1Context = engine.rootContext();
    cellAlarmN1Context->setContextProperty("cellAlarmN1Handler", &m_cellAlarmN1Handler);

    QQmlContext* cellAlarmN2Context = engine.rootContext();
    cellAlarmN2Context->setContextProperty("cellAlarmN2Handler", &m_cellAlarmN2Handler);

    QQmlContext* cellAlarmN3Context = engine.rootContext();
    cellAlarmN3Context->setContextProperty("cellAlarmN3Handler", &m_cellAlarmN3Handler);

    QQmlContext* packSummaryHandler = engine.rootContext();
    packSummaryHandler->setContextProperty("packSummaryHandler", &m_packSummaryHandler);

    QQmlContext* serialUpdaterHandler = engine.rootContext();
    serialUpdaterHandler->setContextProperty("serialUpdaterHandler", &m_serialUpdater);

    QQmlContext* settingsContext = engine.rootContext();
    settingsContext->setContextProperty("settingsHandler", &m_settingsHandler);

    QQmlContext* cellOverviewContext = engine.rootContext();
    cellOverviewContext->setContextProperty("cellOverviewHandler", &m_cellOverviewHandler);

    QQmlContext* csvExporterContext = engine.rootContext();
    csvExporterContext->setContextProperty("csvExporterHandler", &m_csvExporterHandler);

    const QUrl url(u"qrc:/BMS_GUI/Main.qml"_qs);
    QObject::connect(&engine, &QQmlApplicationEngine::objectCreationFailed,
        &app, []() { QCoreApplication::exit(-1); },
        Qt::QueuedConnection);
    engine.load(url);

    timerUpdateQML.start(500);

    return app.exec();
}
